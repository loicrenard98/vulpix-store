# Atelier-Blocs

Grande démo du **mode blocs** : presque tous les blocs de la palette, rangés en
5 zones expliquées par des notes 📌.

## Utilisation
1. Clique sur **✎** pour ouvrir l'éditeur de blocs, puis sur **Tout afficher**.
2. Clique sur **▶ Lancer** et ouvre **▤ Console**.
3. Les zones ①, ② et ③ s'exécutent tout de suite. La zone ④ attend tes actions :
   le projet reste lancé jusqu'à **■ Arrêter**.

## Les zones
| Zone | Ce qu'elle montre |
|------|-------------------|
| ① Données | Date, dé, calcul, texte en majuscules, variable, condition « Si », notification |
| ② Fichiers et boucles | Écrire / lire `journal.txt`, compter les lignes, Répéter, Lister un dossier, Pour chaque |
| ③ Web et scripts | Essayer (gestion d'erreur), requête web, JSON, JavaScript, PowerShell |
| ④ Déclencheurs | Raccourci Ctrl+Alt+V, presse-papiers, Bloc-notes ouvert, fichier créé, toutes les minutes, inactivité + Arrêter |
| ⑤ Ranger ses fichiers | Ctrl+Alt+B : créer un dossier, copier, presse-papiers, attendre, ouvrir |

## À essayer
- Change le seuil du bloc « Si » de la zone ①.
- Remplace l'adresse de la requête web par une autre API.
- Mets le chemin de ton dossier Téléchargements dans « Fichier modifié ».

Le chapitre 8 du **Tutoriel** explique chaque bloc un par un.
