using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using Vulpix;

namespace VulpixProject
{
    // Calculatrice : lire des TextBox, calculer, écrire le résultat
    // et ajouter une ligne dans une ListBox.
    public class Code : VulpixScript
    {
        private void Additionner_Click(object sender, RoutedEventArgs e) => Calculer('+');
        private void Soustraire_Click(object sender, RoutedEventArgs e) => Calculer('−');
        private void Multiplier_Click(object sender, RoutedEventArgs e) => Calculer('×');
        private void Diviser_Click(object sender, RoutedEventArgs e) => Calculer('÷');

        private void Effacer_Click(object sender, RoutedEventArgs e)
        {
            TextBox? a = GetElement<TextBox>("Nombre1");
            TextBox? b = GetElement<TextBox>("Nombre2");
            if (a != null) a.Text = "";
            if (b != null) b.Text = "";

            GetElement<ListBox>("Historique")?.Items.Clear();
            Afficher("= ?");
        }

        private void Calculer(char operation)
        {
            if (!LireNombre("Nombre1", out double a) || !LireNombre("Nombre2", out double b))
            {
                Afficher("Entre deux nombres valides.");
                return;
            }

            if (operation == '÷' && b == 0)
            {
                Afficher("Division par zéro impossible.");
                return;
            }

            double resultat = operation switch
            {
                '+' => a + b,
                '−' => a - b,
                '×' => a * b,
                _ => a / b
            };

            string texte = Formater(resultat);
            Afficher("= " + texte);

            // Le calcul le plus récent en haut de la liste.
            GetElement<ListBox>("Historique")?.Items.Insert(0, $"{Formater(a)} {operation} {Formater(b)} = {texte}");
        }

        // Accepte la virgule comme le point : "2,5" et "2.5".
        private bool LireNombre(string nomDuChamp, out double valeur)
        {
            string texte = GetElement<TextBox>(nomDuChamp)?.Text.Trim().Replace(',', '.') ?? "";
            return double.TryParse(texte, NumberStyles.Float, CultureInfo.InvariantCulture, out valeur);
        }

        private static string Formater(double nombre) =>
            nombre.ToString("0.##########", CultureInfo.GetCultureInfo("fr-FR"));

        private void Afficher(string texte)
        {
            TextBlock? resultat = GetElement<TextBlock>("Resultat");
            if (resultat != null)
                resultat.Text = texte;
        }
    }
}
