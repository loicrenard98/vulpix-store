# Calculatrice

Exemple d'interface simple : deux champs de saisie, quatre opérations et un
historique des calculs.

## Ce que montre cet exemple
- Lire le texte d'une `TextBox` avec `GetElement<TextBox>("Nombre1")`.
- Relier plusieurs boutons à des méthodes différentes (`Additionner_Click`…).
- Remplir une `ListBox` depuis le code (`Items.Insert`).
- Définir un style local (`Operation`) réutilisé par plusieurs boutons.

## Idées d'amélioration
- Ajouter un bouton « Puissance » (`Math.Pow(a, b)`).
- Ajouter un bouton « Racine carrée » qui n'utilise que le premier nombre.
- Enregistrer l'historique dans un fichier dans `OnClose()`.
