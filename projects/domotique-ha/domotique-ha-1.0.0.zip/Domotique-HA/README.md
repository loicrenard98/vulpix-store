# Domotique-HA

Exemple de projet blocs relié à **Home Assistant**.

## Préparer
1. Dans Home Assistant : ton profil → Sécurité → **Jetons d'accès longue durée** → Créer.
2. Dans Vulpix : **Paramètres → Home Assistant** → adresse + jeton → « Enregistrer et tester ».

## Ce que fait l'exemple
- **Au lancement** : lit l'entité `sun.sun` et écrit dans la console s'il fait jour ou nuit.
- **Porte ouverte** (`binary_sensor.porte` passe à `on`) : notification sur le PC.
- **Ctrl+Alt+L** : bascule `light.bureau`.

Remplace `binary_sensor.porte` et `light.bureau` par tes entités : clique sur le
bloc, puis sur **…** à côté du champ « Entité ».

## Les blocs Home Assistant
| Bloc | Rôle |
|---|---|
| Entité HA change d'état | Démarre quand une entité change (filtre « de… / vers… ») |
| Événement Home Assistant | Démarre quand une automatisation HA envoie un événement |
| Allumer / éteindre | Allume, éteint ou bascule une lampe, une prise… |
| Appeler un service HA | N'importe quel service (scènes, scripts, chauffage…) |
| Lire une entité HA | État + attributs dans des variables |
| Notification HA (téléphone) | Notification via `notify.mobile_app_…` |
| Envoyer un événement à HA | Pour déclencher une automatisation HA depuis le PC |
